# Project 2 — Drone Fleet Optimization for Infrastructure Monitoring

> Plan and operate a drone fleet inspecting ~480 distributed assets. Chains a set-covering depot-location ILP, a battery-aware VRP-D with time windows, and a genetic-algorithm online repair engine for weather disruptions.

[![Technique](https://img.shields.io/badge/Technique-VRP--D%20%2B%20Set%20Covering-blue)]()
[![Domain](https://img.shields.io/badge/Domain-Logistics-teal)]()

## Problem Statement
A utility operator inspects ~480 assets (towers, pipelines, bridges) across a 250×250 km region. Ground crews average 23 days/inspection cycle and miss post-storm 2-hour SLAs 59% of the time. Migrating to drones raises three questions: where to place mobile depots, which drone visits which asset, and how to re-plan in seconds when weather grounds a depot.

## Solution — Three-Stage Pipeline
1. **Set-covering ILP** — minimum-cost depots such that every asset is within drone round-trip range
2. **VRP-D** — Clarke-Wright savings + 2-opt per depot; battery (Wh) and time windows enforced
3. **GA repair** — ordered crossover + swap mutation; re-plans 50 assets in < 0.5 s

## Key Results

| Metric | Ground crews | Drone fleet | Delta |
|--------|-------------|-------------|-------|
| Annual mission cost | $1.85M | $1.26M | **−32%** |
| Asset drone coverage | 100% (slow) | 88% | + manual for 12% |
| Storm SLA (2h) hit rate | 41% | **100%** | **+59 pts** |
| Online re-plan (50 assets) | N/A | **< 0.5 s** | — |

## How to Run
```bash
pip install -r ../../requirements.txt
cd src
python main.py
```

## Resume Bullet
> Built a 3-stage drone supply-chain optimizer (depot ILP + VRP-D + GA repair) projecting **−32% annual inspection cost** and **+59-point improvement** in post-storm 2-hour SLA compliance across 480 distributed infrastructure assets.
