# Project Charter — 02-drone-supply-chain

## Objectives & Success Metrics
See README.md for full results.

## Stakeholders
| Role | Responsibility |
|------|---------------|
| OR engineer (lead) | Models, code, results |
| Domain SME | Validates feasibility |
| Sponsor | Go/no-go decision |

## Milestones
| Week | Milestone |
|------|-----------|
| 1 | Data collection & EDA |
| 2–3 | Core model development |
| 4 | Validation & sensitivity |
| 5 | Executive readout |
