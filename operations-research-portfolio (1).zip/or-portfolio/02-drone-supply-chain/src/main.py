"""
main.py — Project 2: Drone Supply Chain Optimization
Runs the 3-stage pipeline: depot ILP → VRP-D → GA repair.
"""
import os, sys, time, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))
from data_generator  import build_scenario
from depot_location  import solve_depot_cover
from vrp_drones      import plan_all
from ga_repair       import ga_repair

HERE    = os.path.dirname(__file__)
RESULTS = os.path.join(HERE, "..", "results")
os.makedirs(RESULTS, exist_ok=True)


def cost_estimate(plan, scenario, chosen):
    km      = plan["summary"]["total_km"]
    routes  = sum(p["n_routes"] for p in plan["plans"].values())
    flight  = km * 0.45
    pilot   = routes * 20 * 1.20
    depot_c = sum(d.setup_cost/3+365*d.daily_cost for d in scenario["depots"] if d.did in chosen)
    weekly  = flight+pilot
    return {"flight_weekly":flight,"pilot_weekly":pilot,
            "depot_annual":depot_c,"annual_total":weekly*52+depot_c}


def make_plots(scenario, chosen, plan):
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    fig.suptitle("Project 2 — Drone Supply Chain Optimization", fontsize=13, fontweight="bold")

    # 1) asset map
    ax = axes[0]; ax.set_title("Asset map & depot coverage")
    classes = [a.asset_class for a in scenario["assets"]]
    xs = [a.x for a in scenario["assets"]]; ys = [a.y for a in scenario["assets"]]
    colors = {"tower":"#AFA9EC","pipeline":"#5DCAA5","transmission":"#FAC775","bridge":"#F09595"}
    for cls in set(classes):
        idx = [i for i,c in enumerate(classes) if c==cls]
        ax.scatter([xs[i] for i in idx],[ys[i] for i in idx],
                   s=6,alpha=0.5,color=colors.get(cls,"#888780"),label=cls)
    depots = scenario["depots"]
    for d in depots:
        col = "#E24B4A" if d.did in chosen else "#D3D1C7"
        ax.scatter(d.x,d.y,s=80,marker="^",color=col,zorder=5)
        if d.did in chosen:
            circle=plt.Circle((d.x,d.y),140*0.55,color="#E24B4A",fill=False,alpha=0.2,linewidth=0.8)
            ax.add_patch(circle)
    ax.legend(fontsize=7,loc="upper right"); ax.set_aspect("equal")

    # 2) priority distribution
    ax = axes[1]; ax.set_title("Asset priority distribution")
    pris = [a.priority for a in scenario["assets"]]
    ax.bar([1,2,3],[pris.count(p) for p in [1,2,3]],
           color=["#5DCAA5","#FAC775","#E24B4A"],alpha=0.85)
    ax.set_xlabel("Priority"); ax.set_ylabel("Count")
    ax.set_xticks([1,2,3]); ax.set_xticklabels(["Normal","High","Storm-critical"])

    # 3) cost comparison
    ax = axes[2]; ax.set_title("Annual cost comparison")
    costs = cost_estimate(plan, scenario, chosen)
    labels = ["Status quo\n(trucks)","Drone fleet\n(optimized)"]
    vals   = [1_850_000, costs["annual_total"]]
    bars   = ax.bar(labels, vals, color=["#F09595","#5DCAA5"], alpha=0.85)
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x()+bar.get_width()/2, val+20000, f"${val:,.0f}", ha="center", fontsize=9)
    ax.set_ylabel("Annual cost ($)")

    plt.tight_layout()
    out = os.path.join(RESULTS, "drone_results.png")
    plt.savefig(out, dpi=120, bbox_inches="tight")
    plt.close(); print(f"  Plot saved → {out}")


def main():
    print("="*60)
    print("Project 2 — Drone Supply Chain Optimization")
    print("="*60)
    sc = build_scenario(n_assets=480,n_candidates=12,seed=7)
    print(f"Scenario: {len(sc['assets'])} assets, {len(sc['depots'])} depot candidates")

    print("\n[Stage 1] Depot covering ILP …", end=" ", flush=True)
    t0=time.time(); chosen=solve_depot_cover(sc); t1=time.time()
    cover = sc["cover"]
    covered = sum(1 for a in sc["assets"] if any(cover[a.aid,d]==1 for d in chosen))
    print(f"done in {t1-t0:.2f}s  |  depots={chosen}  |  coverage={covered}/{len(sc['assets'])}")

    print("[Stage 2] VRP-D per depot …", end=" ", flush=True)
    t0=time.time(); plan=plan_all(sc,chosen); t1=time.time()
    s=plan["summary"]
    print(f"done in {t1-t0:.2f}s  |  km={s['total_km']:,.0f}  |  SLA={s['sla_rate']:.1%}")

    costs=cost_estimate(plan,sc,chosen)
    sq=1_850_000
    print(f"\n  Annual cost: optimized=${costs['annual_total']:,.0f}  sq=${sq:,.0f}  Δ={((costs['annual_total']-sq)/sq*100):+.1f}%")

    print("\n[Stage 3] GA repair (weather disruption simulation) …", end=" ", flush=True)
    biggest = max(plan["plans"],key=lambda d:plan["plans"][d]["n_assets_served"])
    aids_flat = [a for r in plan["plans"][biggest]["routes"] for a in r][:50]
    al = {a.aid:a for a in sc["assets"]}
    xys  = [(al[a].x,al[a].y) for a in aids_flat]
    pris = [al[a].priority for a in aids_flat]
    dep  = next(d for d in sc["depots"] if d.did==biggest)
    t0=time.time()
    rep=ga_repair(list(range(len(aids_flat))),(dep.x,dep.y),xys,pris,seed=11)
    t1=time.time()
    print(f"done in {t1-t0:.2f}s  |  km={rep['distance_km']:.1f}")

    out={"chosen_depots":chosen,"plan_summary":s,"costs":costs,
         "ga":{"n_assets":len(aids_flat),"km":rep["distance_km"],"time_s":round(t1-t0,3)}}
    with open(os.path.join(RESULTS,"summary.json"),"w") as f:
        json.dump(out,f,indent=2,default=str)
    make_plots(sc,chosen,plan)
    print(f"\nOutputs → {RESULTS}")


if __name__=="__main__":
    main()
