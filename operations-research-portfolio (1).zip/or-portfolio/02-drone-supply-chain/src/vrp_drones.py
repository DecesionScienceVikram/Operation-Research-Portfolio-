"""
vrp_drones.py — Project 2
Battery-aware VRP-D: Clarke-Wright savings + 2-opt local search.
Priority-3 assets get dedicated express routes to meet 2-hour SLA.
"""
import math
from typing import Dict, List, Tuple


def euclid(a, b): return math.hypot(a[0]-b[0], a[1]-b[1])


def savings_routes(depot_xy, asset_xys, drone_range_km, drone_cap_kg,
                   asset_payloads, reserve=0.15):
    n = len(asset_xys)
    if n == 0: return []
    d0   = [euclid(depot_xy,p) for p in asset_xys]
    pair = [[euclid(asset_xys[i],asset_xys[j]) for j in range(n)] for i in range(n)]
    sav  = sorted([(d0[i]+d0[j]-pair[i][j],i,j) for i in range(n) for j in range(i+1,n)], reverse=True)
    route_of = list(range(n))
    routes: Dict[int,List[int]] = {i:[i] for i in range(n)}
    lim  = drone_range_km*(1.0-reserve)
    cap  = drone_cap_kg

    def rlen(r):
        if not r: return 0
        L = euclid(depot_xy,asset_xys[r[0]])
        for k in range(len(r)-1): L += pair[r[k]][r[k+1]]
        return L + euclid(asset_xys[r[-1]],depot_xy)
    def rcap(r): return sum(asset_payloads[i] for i in r)

    for s,i,j in sav:
        if s<=0: break
        ri,rj = route_of[i],route_of[j]
        if ri==rj: continue
        Ri,Rj = routes[ri],routes[rj]
        if i not in (Ri[0],Ri[-1]) or j not in (Rj[0],Rj[-1]): continue
        if   Ri[-1]==i and Rj[0]==j:  new = Ri+Rj
        elif Ri[0]==i  and Rj[-1]==j: new = Rj+Ri
        elif Ri[0]==i  and Rj[0]==j:  new = list(reversed(Ri))+Rj
        else:                          new = Ri+list(reversed(Rj))
        if rcap(new)>cap or rlen(new)>lim: continue
        routes[ri] = new
        for k in new: route_of[k] = ri
        del routes[rj]
    return list(routes.values())


def two_opt(route, points, depot_xy, max_iter=40):
    best = route[:]
    imp  = True; itr = 0
    while imp and itr<max_iter:
        imp=False; itr+=1
        for i in range(len(best)-1):
            for j in range(i+2,len(best)):
                pa=points[best[i]]; pb=points[best[i+1]]
                pc=points[best[j]]; pd=points[best[j+1]] if j+1<len(best) else depot_xy
                if euclid(pa,pc)+euclid(pb,pd) < euclid(pa,pb)+euclid(pc,pd)-1e-9:
                    best=best[:i+1]+list(reversed(best[i+1:j+1]))+best[j+1:]
                    imp=True
    return best


def plan_all(scenario: Dict, chosen_depots: List[int]) -> Dict:
    assets     = scenario["assets"]
    depots     = scenario["depots"]
    drones     = scenario["drones"]
    cover      = scenario["cover"]
    al         = {a.aid:a for a in assets}
    chosen_dr  = max(drones, key=lambda d:d.range_km)
    assignment = {did:[] for did in chosen_depots}
    for a in assets:
        cands = [did for did in chosen_depots if cover[a.aid,did]==1]
        if not cands: continue
        d_lu  = {d.did:d for d in depots}
        best  = min(cands, key=lambda did:euclid((a.x,a.y),(d_lu[did].x,d_lu[did].y)))
        assignment[best].append(a.aid)

    plans   = {}
    summary = {"total_km":0.0,"total_assets":0,"sla_hits":0,"sla_total":0}
    for did, aids in assignment.items():
        if not aids: continue
        depot   = next(d for d in depots if d.did==did)
        dep_xy  = (depot.x, depot.y)
        p3      = [a for a in aids if al[a].priority==3]
        rest    = [a for a in aids if al[a].priority!=3]
        xys_all = {a:(al[a].x,al[a].y) for a in aids}
        express = []
        used    = set()
        for aid in p3:
            if aid in used: continue
            partner = None; best_d=float("inf")
            for aid2 in p3:
                if aid2==aid or aid2 in used: continue
                d = euclid(xys_all[aid],xys_all[aid2])
                if d<best_d and d<25: best_d,partner=d,aid2
            route = [aid] if partner is None else [aid,partner]
            used.update(route); express.append(route)
        rest_xys     = [xys_all[a] for a in rest]
        rest_payloads= [1.0]*len(rest)
        saved = savings_routes(dep_xy,rest_xys,chosen_dr.range_km,chosen_dr.payload_kg,rest_payloads)
        saved = [two_opt(r,rest_xys,dep_xy) for r in saved]
        reg_global = [[rest[i] for i in r] for r in saved]
        all_routes  = express + reg_global
        total_km=0.0; sla_h=0; sla_t=0; served=0
        for r in all_routes:
            elapsed=0.0; prev=dep_xy
            for aid in r:
                here=(al[aid].x,al[aid].y)
                d=euclid(prev,here); total_km+=d
                elapsed+=d/chosen_dr.speed_kmh*60+al[aid].inspection_minutes
                if al[aid].priority==3:
                    sla_t+=1
                    if elapsed<=120: sla_h+=1
                prev=here; served+=1
            total_km+=euclid(prev,dep_xy)
        plans[did]={"depot_id":did,"n_routes":len(all_routes),"n_assets_served":served,
                    "total_km":total_km,"sla_hits":sla_h,"sla_total":sla_t,"routes":all_routes}
        summary["total_km"]    +=total_km
        summary["total_assets"]+=served
        summary["sla_hits"]    +=sla_h
        summary["sla_total"]   +=sla_t
    summary["sla_rate"]=summary["sla_hits"]/summary["sla_total"] if summary["sla_total"]>0 else 1.0
    return {"plans":plans,"summary":summary}
