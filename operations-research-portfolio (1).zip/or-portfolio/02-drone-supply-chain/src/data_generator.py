"""
data_generator.py — Project 2: Drone Supply Chain
480 infrastructure assets, 12 depot candidates, 4 drones, weather windows.
"""
import math, numpy as np, pandas as pd
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple


@dataclass
class Asset:
    aid: int; x: float; y: float
    asset_class: str; priority: int; inspection_minutes: float

@dataclass
class DepotCandidate:
    did: int; x: float; y: float
    setup_cost: float; daily_cost: float; weather_risk: float

@dataclass
class Drone:
    drone_id: int; range_km: float; payload_kg: float
    speed_kmh: float; battery_wh: float; drain_wh_per_km: float


def euclid(a: Tuple, b: Tuple) -> float:
    return math.hypot(a[0]-b[0], a[1]-b[1])


def build_scenario(n_assets=480, n_candidates=12, region_km=250.0, seed=7) -> Dict:
    rng = np.random.default_rng(seed)
    classes  = ["tower","pipeline","transmission","bridge"]
    cw       = [0.45,0.20,0.25,0.10]
    insp_min = {"tower":8,"pipeline":12,"transmission":6,"bridge":18}

    assets: List[Asset] = []
    for a in range(n_assets):
        cls = str(rng.choice(classes, p=cw))
        pri = int(rng.choice([1,2,3], p=[0.70,0.22,0.08]))
        if cls == "tower" and rng.random() < 0.6:
            cx,cy = rng.uniform(40,region_km-40,size=2)
            x,y   = cx+rng.normal(0,8), cy+rng.normal(0,8)
        else:
            x,y = rng.uniform(0,region_km,size=2)
        assets.append(Asset(aid=a,x=float(x),y=float(y),asset_class=cls,
                            priority=pri,inspection_minutes=float(insp_min[cls]+rng.normal(0,1))))

    grid = int(math.ceil(math.sqrt(n_candidates)))
    sp   = region_km/(grid+1)
    depots: List[DepotCandidate] = []
    did  = 0
    for i in range(grid):
        for j in range(grid):
            if did >= n_candidates: break
            x = float(np.clip((i+1)*sp+rng.normal(0,8),0,region_km))
            y = float(np.clip((j+1)*sp+rng.normal(0,8),0,region_km))
            depots.append(DepotCandidate(did=did,x=x,y=y,
                setup_cost=float(rng.uniform(40000,90000)),
                daily_cost=float(rng.uniform(180,320)),
                weather_risk=float(rng.uniform(0.05,0.20))))
            did += 1

    drones = [
        Drone(0,range_km=80, payload_kg=2.0,speed_kmh=60,battery_wh=600, drain_wh_per_km=15),
        Drone(1,range_km=80, payload_kg=2.0,speed_kmh=60,battery_wh=600, drain_wh_per_km=15),
        Drone(2,range_km=140,payload_kg=4.0,speed_kmh=70,battery_wh=1400,drain_wh_per_km=18),
        Drone(3,range_km=140,payload_kg=4.0,speed_kmh=70,battery_wh=1400,drain_wh_per_km=18),
    ]
    long_range = max(d.range_km for d in drones)
    cover = np.zeros((n_assets,len(depots)),dtype=int)
    for a in assets:
        for d in depots:
            if euclid((a.x,a.y),(d.x,d.y))*2.0*1.15 <= long_range:
                cover[a.aid,d.did] = 1

    return {"assets":assets,"depots":depots,"drones":drones,
            "cover":cover,"region_km":region_km}


if __name__ == "__main__":
    sc = build_scenario()
    print(f"Assets:{len(sc['assets'])} Depots:{len(sc['depots'])} Drones:{len(sc['drones'])}")
    print(f"Avg depots covering each asset: {sc['cover'].sum(axis=1).mean():.1f}")
