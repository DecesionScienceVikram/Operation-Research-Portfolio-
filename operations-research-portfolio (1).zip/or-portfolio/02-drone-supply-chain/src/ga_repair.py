"""
ga_repair.py — Project 2
Genetic algorithm for online route repair after weather disruptions.
Ordered crossover (OX) + swap mutation. Converges in ~80 generations.
"""
import numpy as np, math, time
from typing import List, Tuple, Dict


def euclid(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])

def route_dist(perm,depot_xy,xys):
    if not perm: return 0.0
    d=euclid(depot_xy,xys[perm[0]])
    for i in range(len(perm)-1): d+=euclid(xys[perm[i]],xys[perm[i+1]])
    return d+euclid(xys[perm[-1]],depot_xy)

def fitness(ind,depot_xy,xys,pris,speed_kmh,sla_min,sla_pen):
    km=0.0; elapsed=0.0; breaches=0; prev=depot_xy
    for k in ind:
        d=euclid(prev,xys[k]); km+=d; elapsed+=d/speed_kmh*60+8.0
        if pris[k]==3 and elapsed>sla_min: breaches+=1
        prev=xys[k]
    return km+euclid(prev,depot_xy)+sla_pen*breaches

def ox(p1,p2,rng):
    n=len(p1)
    if n<2: return p1[:]
    a,b=sorted(rng.choice(n,size=2,replace=False))
    child=[-1]*n; child[a:b+1]=p1[a:b+1]
    fill=[g for g in p2 if g not in child]; idx=0
    for i in range(n):
        if child[i]==-1: child[i]=fill[idx]; idx+=1
    return child

def swap_mut(ind,rng,p=0.15):
    ind=ind[:]
    if rng.random()<p and len(ind)>=2:
        i,j=rng.choice(len(ind),size=2,replace=False); ind[i],ind[j]=ind[j],ind[i]
    return ind

def ga_repair(asset_indices,depot_xy,all_xys,all_pris,
              speed_kmh=55.0,sla_minutes=120.0,sla_penalty=50.0,
              pop_size=60,generations=80,seed=0):
    rng=np.random.default_rng(seed)
    if not asset_indices:
        return {"order":[],"distance_km":0.0,"fitness":0.0}
    xys=[(all_xys[k][0],all_xys[k][1]) for k in asset_indices]
    pris=[all_pris[k] for k in asset_indices]
    n=len(asset_indices)
    pop=[rng.permutation(n).tolist() for _ in range(pop_size-1)]
    visited=[False]*n; cur=depot_xy; nn=[]
    while len(nn)<n:
        bk,bd=-1,float("inf")
        for k in range(n):
            if not visited[k]:
                d=euclid(cur,xys[k])
                if d<bd: bd,bk=d,k
        nn.append(bk); visited[bk]=True; cur=xys[bk]
    pop.append(nn)
    fits=[fitness(i,depot_xy,xys,pris,speed_kmh,sla_minutes,sla_penalty) for i in pop]
    bi=int(np.argmin(fits)); best=pop[bi][:]; bf=fits[bi]
    for _ in range(generations):
        new=[]
        for _ in range(pop_size):
            c=rng.choice(pop_size,size=3,replace=False)
            new.append(pop[min(c,key=lambda i:fits[i])][:])
        off=[]
        for i in range(0,pop_size,2):
            if i+1>=pop_size: off.append(new[i]); continue
            off.append(swap_mut(ox(new[i],new[i+1],rng),rng))
            off.append(swap_mut(ox(new[i+1],new[i],rng),rng))
        off[0]=best[:]
        pop=off; fits=[fitness(i,depot_xy,xys,pris,speed_kmh,sla_minutes,sla_penalty) for i in pop]
        gi=int(np.argmin(fits))
        if fits[gi]<bf: bf=fits[gi]; best=pop[gi][:]
    return {"order":[asset_indices[k] for k in best],
            "distance_km":route_dist(best,depot_xy,xys),"fitness":bf}
