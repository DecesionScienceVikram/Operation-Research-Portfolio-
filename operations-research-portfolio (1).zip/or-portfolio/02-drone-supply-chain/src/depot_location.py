"""
depot_location.py — Project 2
Set-covering ILP: minimum-cost depots covering all reachable assets.
"""
import numpy as np, pulp
from typing import Dict, List


def solve_depot_cover(scenario: Dict, weather_penalty: float = 50_000) -> List[int]:
    depots = scenario["depots"]
    cover  = scenario["cover"]
    n_assets = len(scenario["assets"])
    uncovered = np.where(cover.sum(axis=1) == 0)[0]
    if len(uncovered):
        print(f"  WARNING: {len(uncovered)} assets unreachable by any depot (manual fallback).")
    keep = np.where(cover.sum(axis=1) > 0)[0]

    prob = pulp.LpProblem("depot_cover", pulp.LpMinimize)
    y    = {d.did: pulp.LpVariable(f"y_{d.did}", cat="Binary") for d in depots}
    prob += pulp.lpSum(
        (d.setup_cost/3.0 + 365*d.daily_cost + weather_penalty*d.weather_risk)*y[d.did]
        for d in depots)
    for a_idx in keep:
        covers = [d.did for d in depots if cover[a_idx,d.did]==1]
        prob  += pulp.lpSum(y[did] for did in covers) >= 1, f"cov_{a_idx}"
    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    return [did for did,var in y.items() if var.value() and var.value()>0.5]
