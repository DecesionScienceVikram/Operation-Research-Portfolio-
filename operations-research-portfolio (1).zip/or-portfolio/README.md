# Operations Research & Optimization Portfolio

> Six end-to-end OR projects spanning manufacturing, logistics, supply chain, and strategic decision-making. Each project combines mathematical optimization, simulation, machine learning, and data engineering to solve real-world business challenges.

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)]()
[![License](https://img.shields.io/badge/License-MIT-green)]()
[![Status](https://img.shields.io/badge/Status-Active-success)]()
[![OR](https://img.shields.io/badge/Field-Operations%20Research-purple)]()

---

## Portfolio Overview

| # | Project | Techniques | Headline Result |
|---|---------|-----------|-----------------|
| 1 | [Digital Twin Manufacturing](./01-digital-twin-manufacturing) | MILP · Multi-Agent RL · SimPy DES | −65% operator fatigue |
| 2 | [Drone Supply Chain](./02-drone-supply-chain) | VRP-D · Set Covering · Genetic Algorithm | −32% mission cost |
| 3 | [Port Terminal Operations](./03-port-terminal-optimization) | BAP · QCASP · Queuing Theory | −22% vessel turnaround |
| 4 | [EV Battery Supply Chain](./04-ev-battery-supply-chain) | Stochastic Inventory · Network Flow · Last-Mile VRP | $4.7M savings projected |
| 5 | [Build vs Buy Analysis](./05-build-vs-buy-analysis) | NPV · Real Options · Monte Carlo · AHP/TOPSIS | Robust sourcing framework |
| 6 | [Capstone: Resilient Network](./06-capstone-integrated-network) | Two-Stage Stochastic Programming · Bayesian Forecasting | Unified decision support |

---

## How to Run Any Project

```bash
# 1. Clone this repo
git clone https://github.com/YOUR-USERNAME/operations-research-portfolio.git
cd operations-research-portfolio

# 2. Install all dependencies
pip install -r requirements.txt

# 3. Run any project
cd 01-digital-twin-manufacturing
python src/main.py
```

Every `main.py` is self-contained — it generates data, runs the model, prints results, and saves outputs to `results/`.

---

## Tech Stack

| Category | Libraries |
|----------|-----------|
| Optimization | PuLP, OR-Tools, SciPy, CVXPY |
| Simulation | SimPy, NumPy |
| Machine Learning | scikit-learn, custom RL agents |
| Data Engineering | Pandas, NumPy, Polars |
| Visualization | Matplotlib, Plotly, Seaborn |
| Decision Analysis | Custom AHP/TOPSIS, Monte Carlo |

---

## Author

Built as a portfolio demonstrating applied operations research across manufacturing, logistics, and supply chain domains.

LinkedIn: [Your LinkedIn URL]
GitHub: [Your GitHub URL]
