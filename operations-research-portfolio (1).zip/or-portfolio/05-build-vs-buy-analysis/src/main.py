"""
Project 5: Strategic Build vs Buy Analysis
main.py — NPV + Real Options + Monte Carlo + AHP/TOPSIS decision framework.
"""
import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE    = os.path.dirname(__file__)
RESULTS = os.path.join(HERE, "..", "results")
os.makedirs(RESULTS, exist_ok=True)


# ── Scenario definition ───────────────────────────────────────────
def get_options():
    """Three sourcing options for a logistics optimization platform."""
    return [
        {
            "name": "Build in-house",
            "capex": 2_400_000, "annual_opex": 380_000, "time_to_market_months": 18,
            "quality_score": 9.0, "strategic_fit": 9.5, "risk_score": 7.0,
            "annual_benefit": 1_800_000, "growth_option_value": 600_000,
        },
        {
            "name": "Buy (vendor A)",
            "capex": 850_000, "annual_opex": 420_000, "time_to_market_months": 4,
            "quality_score": 7.5, "strategic_fit": 6.0, "risk_score": 4.5,
            "annual_benefit": 1_500_000, "growth_option_value": 150_000,
        },
        {
            "name": "Partner / hybrid",
            "capex": 1_200_000, "annual_opex": 290_000, "time_to_market_months": 9,
            "quality_score": 8.2, "strategic_fit": 8.0, "risk_score": 5.5,
            "annual_benefit": 1_650_000, "growth_option_value": 350_000,
        },
    ]


# ── NPV analysis ─────────────────────────────────────────────────
def npv_analysis(options, discount_rate=0.10, horizon=7):
    results = []
    for o in options:
        pv_benefits = sum(o["annual_benefit"] / (1+discount_rate)**t for t in range(1,horizon+1))
        pv_opex     = sum(o["annual_opex"]    / (1+discount_rate)**t for t in range(1,horizon+1))
        delay_cost  = o["annual_benefit"] * (o["time_to_market_months"]/12) * 0.5
        npv         = -o["capex"] - pv_opex + pv_benefits - delay_cost + o["growth_option_value"]
        payback_yr  = o["capex"] / max(o["annual_benefit"] - o["annual_opex"], 1)
        irr_approx  = (o["annual_benefit"] - o["annual_opex"]) / o["capex"]
        results.append({"option":o["name"],"npv":round(npv,0),"payback_yr":round(payback_yr,2),
                        "irr_approx":round(irr_approx,3),"total_capex":o["capex"]})
    return pd.DataFrame(results)


# ── Monte Carlo NPV simulation ────────────────────────────────────
def monte_carlo_npv(options, n_sims=5000, discount_rate=0.10, horizon=7, seed=42):
    rng = np.random.default_rng(seed)
    sim_results = {}
    for o in options:
        npvs = []
        for _ in range(n_sims):
            ben  = rng.normal(o["annual_benefit"],   o["annual_benefit"]*0.15,  horizon)
            opex = rng.normal(o["annual_opex"],       o["annual_opex"]*0.12,    horizon)
            capex= rng.normal(o["capex"],             o["capex"]*0.20)
            delay= rng.normal(o["time_to_market_months"], 3) / 12
            pv_b = sum(ben[t]  / (1+discount_rate)**(t+1) for t in range(horizon))
            pv_o = sum(opex[t] / (1+discount_rate)**(t+1) for t in range(horizon))
            dc   = o["annual_benefit"] * delay * 0.5
            npv  = -capex - pv_o + pv_b - dc + o["growth_option_value"]
            npvs.append(npv)
        sim_results[o["name"]] = np.array(npvs)
    return sim_results


# ── AHP / TOPSIS multi-criteria ──────────────────────────────────
def ahp_topsis(options):
    """Rank options on 5 criteria using AHP weights + TOPSIS scoring."""
    criteria    = ["NPV","Time-to-market","Quality","Strategic fit","Risk (inv)"]
    ahp_weights = np.array([0.35, 0.20, 0.20, 0.15, 0.10])
    ahp_weights /= ahp_weights.sum()

    # Decision matrix (higher = better; risk inverted)
    dm = np.array([
        [o["annual_benefit"]*5 - o["capex"], -o["time_to_market_months"],
         o["quality_score"], o["strategic_fit"], 10-o["risk_score"]]
        for o in options
    ], dtype=float)

    # Normalise
    norms = np.linalg.norm(dm, axis=0, keepdims=True)
    norms[norms == 0] = 1
    ndm = dm / norms

    weighted = ndm * ahp_weights
    ideal     = weighted.max(axis=0)
    anti_ideal= weighted.min(axis=0)
    d_pos = np.sqrt(((weighted - ideal)**2).sum(axis=1))
    d_neg = np.sqrt(((weighted - anti_ideal)**2).sum(axis=1))
    score = d_neg / (d_pos + d_neg + 1e-9)
    rank  = score.argsort()[::-1] + 1

    return pd.DataFrame({
        "option":    [o["name"] for o in options],
        "topsis_score": np.round(score, 4),
        "rank":      rank
    }).sort_values("rank")


def make_plots(npv_df, mc_sims, topsis_df):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    fig.suptitle("Project 5 — Strategic Build vs Buy Analysis", fontsize=13, fontweight="bold")
    colors = ["#AFA9EC", "#5DCAA5", "#FAC775"]

    ax = axes[0]; ax.set_title("Deterministic NPV comparison")
    bars = ax.bar(npv_df["option"], npv_df["npv"]/1e6, color=colors, alpha=0.85)
    for b,v in zip(bars, npv_df["npv"]/1e6):
        ax.text(b.get_x()+b.get_width()/2, v+0.05, f"${v:.2f}M", ha="center", fontsize=9)
    ax.set_ylabel("NPV ($M)"); ax.axhline(0, color="#888780", linewidth=0.8, linestyle="--")

    ax = axes[1]; ax.set_title("Monte Carlo NPV distributions")
    for i,(name,sims) in enumerate(mc_sims.items()):
        ax.hist(sims/1e6, bins=40, alpha=0.6, color=colors[i], label=name, edgecolor="none")
        ax.axvline(sims.mean()/1e6, color=colors[i], linewidth=1.5, linestyle="--")
    ax.set_xlabel("NPV ($M)"); ax.legend(fontsize=7)

    ax = axes[2]; ax.set_title("AHP/TOPSIS multi-criteria ranking")
    t = topsis_df.reset_index(drop=True)
    ax.barh(t["option"], t["topsis_score"], color=colors[:len(t)], alpha=0.85)
    ax.set_xlabel("TOPSIS score (higher = better)")
    ax.invert_yaxis()

    plt.tight_layout()
    out = os.path.join(RESULTS, "build_vs_buy_results.png")
    plt.savefig(out, dpi=120, bbox_inches="tight"); plt.close(); print(f"  Plot → {out}")


def main():
    print("="*60); print("Project 5 — Strategic Build vs Buy Analysis"); print("="*60)
    options = get_options()

    print("\n[Step 1] Deterministic NPV analysis …")
    npv_df = npv_analysis(options)
    print(npv_df.to_string(index=False))

    print("\n[Step 2] Monte Carlo simulation (5,000 reps) …", end=" ", flush=True)
    mc = monte_carlo_npv(options)
    print("done")
    for name, sims in mc.items():
        p10,p50,p90 = np.percentile(sims,[10,50,90])
        prob_pos = (sims>0).mean()*100
        print(f"  {name}: P10=${p10/1e6:.2f}M  median=${p50/1e6:.2f}M  P90=${p90/1e6:.2f}M  P(NPV>0)={prob_pos:.0f}%")

    print("\n[Step 3] AHP/TOPSIS ranking …")
    topsis = ahp_topsis(options)
    print(topsis.to_string(index=False))
    rec = topsis.iloc[0]["option"]
    print(f"\n  Recommendation: {rec}")

    make_plots(npv_df, mc, topsis)
    npv_df.to_csv(os.path.join(RESULTS, "npv_results.csv"), index=False)
    topsis.to_csv(os.path.join(RESULTS, "topsis_ranking.csv"), index=False)
    print(f"\nOutputs → {RESULTS}")


if __name__ == "__main__":
    main()
