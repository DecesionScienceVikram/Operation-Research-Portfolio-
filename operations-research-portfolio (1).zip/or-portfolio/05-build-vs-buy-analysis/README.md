# Project 5 — Strategic Build vs Buy Analysis

> Structured financial, operational, and technical analysis to evaluate in-house development vs. external procurement for a logistics optimization platform. Uses deterministic NPV, Monte Carlo simulation (5,000 reps), and AHP/TOPSIS multi-criteria ranking.

[![Technique](https://img.shields.io/badge/Technique-NPV%20%2B%20Monte%20Carlo%20%2B%20TOPSIS-blue)]()
[![Domain](https://img.shields.io/badge/Domain-Strategic%20Decision-teal)]()

## Business Problem
The company must decide whether to build a proprietary logistics optimization platform in-house, purchase a vendor solution, or pursue a hybrid partnership. Each option has different cost structures, time-to-market, quality, strategic alignment, and risk profiles.

## Framework Components

| Component | Method | Key Output |
|-----------|--------|------------|
| Financial analysis | Deterministic NPV (7-year, 10% WACC) | NPV, payback, IRR |
| Risk modelling | Monte Carlo (5,000 simulations) | P10/P50/P90 NPV, P(NPV>0) |
| Multi-criteria | AHP weights + TOPSIS scoring | Overall rank |
| Sensitivity | Tornado chart on key inputs | Top risk drivers |

## Key Results

| Option | NPV | P(NPV>0) | TOPSIS Rank |
|--------|-----|----------|-------------|
| Build in-house | $2.8M | 78% | 1st |
| Partner / hybrid | $2.1M | 82% | 2nd |
| Buy (vendor) | $1.4M | 88% | 3rd |

**Recommendation**: Build in-house gives highest expected NPV and strategic fit; partner/hybrid recommended if time-to-market is a binding constraint.

## How to Run
```bash
pip install -r ../../requirements.txt
cd src
python main.py
```

## Resume Bullet
> Built a structured build-vs-buy decision framework combining 7-year NPV analysis, 5,000-rep Monte Carlo risk simulation, and AHP/TOPSIS multi-criteria ranking — recommended build-in-house for highest strategic value ($2.8M NPV) with hybrid as contingency option.
