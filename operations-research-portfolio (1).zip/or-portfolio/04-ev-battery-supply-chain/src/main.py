"""
Project 4: EV Battery Multi-Echelon Supply Chain Optimization
main.py — Stochastic inventory + network flow + last-mile VRP.
"""
import os, sys, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE    = os.path.dirname(__file__)
RESULTS = os.path.join(HERE, "..", "results")
os.makedirs(RESULTS, exist_ok=True)


# ── Data generation ───────────────────────────────────────────────
def build_scenario(seed=99, n_plants=3, n_dc=5, n_dealers=40, horizon=52):
    """52-week EV battery supply chain scenario."""
    rng = np.random.default_rng(seed)
    plants  = [{"pid":i,"cap_wk":rng.integers(800,1200),"prod_cost":rng.uniform(180,220)} for i in range(n_plants)]
    dcs     = [{"did":i,"holding_cost":rng.uniform(1.5,3.5),"fixed_cost":rng.uniform(5000,12000),"cap":rng.integers(2000,5000)} for i in range(n_dc)]
    dealers = [{"rid":i,"mean_demand":rng.uniform(8,25),"cv":rng.uniform(0.15,0.45)} for i in range(n_dealers)]

    # distance matrix plant→DC and DC→dealer (km, planar approx)
    plant_xy  = rng.uniform(0,500,size=(n_plants,2))
    dc_xy     = rng.uniform(0,500,size=(n_dc,2))
    dealer_xy = rng.uniform(0,500,size=(n_dealers,2))
    ship_pd   = np.hypot(plant_xy[:,None,0]-dc_xy[None,:,0], plant_xy[:,None,1]-dc_xy[None,:,1])  # (plant,dc)
    ship_dd   = np.hypot(dc_xy[:,None,0]-dealer_xy[None,:,0], dc_xy[:,None,1]-dealer_xy[None,:,1])# (dc,dealer)

    # Weekly demand samples for each dealer
    demands = np.array([[max(0, rng.normal(d["mean_demand"], d["cv"]*d["mean_demand"]))
                         for _ in range(horizon)] for d in dealers])
    return {"plants":plants,"dcs":dcs,"dealers":dealers,
            "ship_pd":ship_pd,"ship_dd":ship_dd,"demands":demands,
            "horizon":horizon,"rng":rng}


# ── Stochastic inventory policy (s, S) per DC ────────────────────
def compute_ss_policy(sc):
    """Compute (s, S) reorder points and order-up-to levels for each DC."""
    rng = sc["rng"]
    results = []
    for dc in sc["dcs"]:
        # Aggregate demand across dealers served by this DC (simplified: all dealers)
        dem_per_wk = sc["demands"].sum(axis=0) / len(sc["dcs"])
        mu  = dem_per_wk.mean()
        sig = dem_per_wk.std()
        lt  = 2.0  # lead time weeks
        z   = 1.645  # 95% service level
        ss  = z * sig * np.sqrt(lt)             # safety stock
        rop = mu * lt + ss                       # reorder point s
        eoq = np.sqrt(2 * mu * dc["fixed_cost"] / dc["holding_cost"])
        S   = rop + eoq                          # order-up-to level S
        results.append({"dc_id":dc["did"],"safety_stock":round(ss,1),
                         "reorder_point":round(rop,1),"order_up_to":round(S,1),
                         "eoq":round(eoq,1)})
    return results


# ── Network flow (plant→DC allocation) ───────────────────────────
def solve_network_flow(sc):
    """Allocate weekly production to DCs minimizing shipping cost."""
    try:
        import pulp
    except ImportError:
        return {"status":"pulp_not_found","total_cost":0}

    plants=sc["plants"]; dcs=sc["dcs"]; ship=sc["ship_pd"]
    total_demand = sc["demands"].sum()/sc["horizon"]
    prob = pulp.LpProblem("nf",pulp.LpMinimize)
    x    = {(i,j):pulp.LpVariable(f"x_{i}_{j}",lowBound=0)
            for i in range(len(plants)) for j in range(len(dcs))}
    prob += pulp.lpSum(ship[i,j]*x[i,j] for i,j in x)
    for i,p in enumerate(plants):
        prob += pulp.lpSum(x[i,j] for j in range(len(dcs))) <= p["cap_wk"]*52
    for j,d in enumerate(dcs):
        prob += pulp.lpSum(x[i,j] for i in range(len(plants))) >= total_demand/len(dcs)
        prob += pulp.lpSum(x[i,j] for i in range(len(plants))) <= d["cap"]
    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    flows = {(i,j):x[i,j].value() or 0 for i,j in x}
    return {"status":pulp.LpStatus[prob.status],
            "total_shipping_cost":round(pulp.value(prob.objective) or 0,0),
            "flows":flows}


# ── Last-mile VRP (nearest-neighbour heuristic) ──────────────────
def last_mile_vrp(sc, vehicle_cap=50):
    """Simple nearest-neighbour VRP from each DC to its dealers."""
    import math
    dealers = sc["dealers"]; ship = sc["ship_dd"]
    total_routes=0; total_km=0.0
    for dc_idx in range(len(sc["dcs"])):
        unvisited = list(range(len(dealers)))
        while unvisited:
            load=0; prev=dc_idx; route_km=0.0; route=[]
            while unvisited:
                # nearest unvisited within capacity
                dists = [(ship[dc_idx,r], r) for r in unvisited]
                dists.sort()
                added=False
                for d,r in dists:
                    if load+dealers[r]["mean_demand"]<=vehicle_cap:
                        route.append(r); load+=dealers[r]["mean_demand"]
                        route_km+=ship[dc_idx,r]; unvisited.remove(r); added=True; break
                if not added: break
            route_km+=ship[dc_idx,route[-1]] if route else 0  # return
            total_km+=route_km; total_routes+=1
    return {"n_routes":total_routes,"total_km":round(total_km,0)}


# ── Monte Carlo simulation ────────────────────────────────────────
def simulate(sc, policy, n_reps=20):
    """Simulate 52 weeks under (s,S) policy and measure fill rate + cost."""
    rng = sc["rng"]; results=[]
    for _ in range(n_reps):
        inventory = {dc["did"]: policy[dc["did"]]["order_up_to"] for dc in sc["dcs"]}
        total_cost=0; stockouts=0; orders=0
        for wk in range(sc["horizon"]):
            demand_wk = sc["demands"][:,wk].sum()
            for dc in sc["dcs"]:
                inv=inventory[dc["did"]]
                inv-=demand_wk/len(sc["dcs"])
                if inv<0: stockouts+=1; inv=0
                rop=policy[dc["did"]]["reorder_point"]
                if inv<rop:
                    q=policy[dc["did"]]["order_up_to"]-inv
                    total_cost+=sc["dcs"][dc["did"]]["holding_cost"]*q+sc["dcs"][dc["did"]]["fixed_cost"]
                    inv=policy[dc["did"]]["order_up_to"]; orders+=1
                else:
                    total_cost+=sc["dcs"][dc["did"]]["holding_cost"]*inv*0.02
                inventory[dc["did"]]=max(0,inv)
        fill_rate=1-stockouts/(sc["horizon"]*len(sc["dcs"]))
        results.append({"total_cost":total_cost,"fill_rate":fill_rate,"orders":orders})
    return pd.DataFrame(results)


def make_plots(ss_policy, sim_df, vrp):
    fig,axes=plt.subplots(1,3,figsize=(12,4))
    fig.suptitle("Project 4 — EV Battery Supply Chain Optimization",fontsize=13,fontweight="bold")

    ax=axes[0]; ax.set_title("(s,S) policy by DC")
    dcs=[p["dc_id"] for p in ss_policy]
    s_vals=[p["reorder_point"] for p in ss_policy]
    S_vals=[p["order_up_to"]   for p in ss_policy]
    x=np.arange(len(dcs))
    ax.bar(x-0.2,s_vals,0.38,label="Reorder pt (s)",color="#AFA9EC",alpha=0.85)
    ax.bar(x+0.2,S_vals,0.38,label="Order-up-to (S)",color="#5DCAA5",alpha=0.85)
    ax.set_xticks(x); ax.set_xticklabels([f"DC{d}" for d in dcs]); ax.legend(fontsize=8)

    ax=axes[1]; ax.set_title("Fill rate distribution (sim)")
    ax.hist(sim_df["fill_rate"]*100,bins=10,color="#534AB7",alpha=0.8,edgecolor="white")
    ax.axvline(sim_df["fill_rate"].mean()*100,color="#E24B4A",linestyle="--",label=f"Mean {sim_df['fill_rate'].mean()*100:.1f}%")
    ax.set_xlabel("Fill rate (%)"); ax.legend(fontsize=8)

    ax=axes[2]; ax.set_title("Annual inventory cost distribution")
    ax.hist(sim_df["total_cost"],bins=10,color="#FAC775",alpha=0.85,edgecolor="white")
    ax.axvline(sim_df["total_cost"].mean(),color="#E24B4A",linestyle="--",
               label=f"Mean ${sim_df['total_cost'].mean():,.0f}")
    ax.set_xlabel("Annual cost ($)"); ax.legend(fontsize=8)

    plt.tight_layout()
    out=os.path.join(RESULTS,"ev_battery_results.png")
    plt.savefig(out,dpi=120,bbox_inches="tight"); plt.close(); print(f"  Plot → {out}")


def main():
    print("="*60); print("Project 4 — EV Battery Supply Chain Optimization"); print("="*60)
    sc = build_scenario()
    print(f"Plants:{len(sc['plants'])}  DCs:{len(sc['dcs'])}  Dealers:{len(sc['dealers'])}  Horizon:{sc['horizon']} weeks")

    print("\n[Step 1] Computing (s,S) inventory policies …",end=" ",flush=True)
    ss = compute_ss_policy(sc)
    print("done")
    pol = {p["dc_id"]:p for p in ss}
    for p in ss: print(f"  DC{p['dc_id']}: s={p['reorder_point']:.0f}  S={p['order_up_to']:.0f}  SS={p['safety_stock']:.0f}  EOQ={p['eoq']:.0f}")

    print("\n[Step 2] Network flow (plant→DC) …",end=" ",flush=True)
    nf=solve_network_flow(sc)
    print(f"done  |  status={nf['status']}  shipping_cost=${nf['total_shipping_cost']:,.0f}")

    print("\n[Step 3] Last-mile VRP …",end=" ",flush=True)
    vrp=last_mile_vrp(sc)
    print(f"done  |  routes={vrp['n_routes']}  km={vrp['total_km']:,.0f}")

    print("\n[Step 4] Monte Carlo simulation (20 reps) …",end=" ",flush=True)
    sim=simulate(sc,pol,n_reps=20)
    print("done")
    print(f"  Fill rate: {sim['fill_rate'].mean()*100:.1f}% ± {sim['fill_rate'].std()*100:.1f}%")
    print(f"  Annual cost: ${sim['total_cost'].mean():,.0f} ± ${sim['total_cost'].std():,.0f}")

    make_plots(ss,sim,vrp)
    sim.to_csv(os.path.join(RESULTS,"simulation_results.csv"),index=False)
    print(f"\nOutputs → {RESULTS}")


if __name__=="__main__":
    main()
