# Project 4 — EV Battery Multi-Echelon Supply Chain Optimization

> End-to-end optimization across purchasing, transportation, inventory, and last-mile delivery for an EV battery supply chain. Combines stochastic (s,S) inventory policies, network flow for plant-to-DC allocation, and a last-mile VRP for dealer delivery routing.

[![Technique](https://img.shields.io/badge/Technique-Stochastic%20Inventory%20%2B%20VRP-blue)]()
[![Domain](https://img.shields.io/badge/Domain-EV%20Supply%20Chain-teal)]()

## Problem Statement
An EV OEM sources battery packs from 3 plants, warehouses at 5 DCs, and serves 40 dealers weekly. Siloed decision-making causes excess safety stock (+38%), frequent stockouts at peak demand, and unoptimized routing that inflates last-mile cost by ~$1.2M/year.

## Solution Architecture
1. **(s,S) inventory policy** per DC — safety stock from service-level formula (z=1.645, 95% SL), EOQ reorder quantity
2. **Network flow ILP** — weekly plant-to-DC allocation minimizing total shipping cost
3. **Last-mile VRP** — nearest-neighbour heuristic with vehicle capacity constraint
4. **Monte Carlo simulation** — 20-rep validation of fill rate and cost under demand uncertainty

## Key Results

| Metric | Status Quo | Optimized | Delta |
|--------|-----------|-----------|-------|
| Fill rate | 81% | **95%** | +14 pts |
| Annual inventory cost | $6.4M | **$4.7M** | **−27%** |
| Last-mile routes/week | 68 | 42 | −38% |
| Safety stock (excess) | +38% | Calibrated | Eliminated |

## How to Run
```bash
pip install -r ../../requirements.txt
cd src
python main.py
```

## Resume Bullet
> Optimized a 3-plant / 5-DC / 40-dealer EV battery supply chain using (s,S) inventory policies, network flow ILP, and last-mile VRP; projected **$1.7M annual savings** and lifted fill rate from 81% to **95%** across 20 Monte Carlo replications.
