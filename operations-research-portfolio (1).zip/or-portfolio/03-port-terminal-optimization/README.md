# Project 3 — Container Terminal Operations Optimization

> Joint optimization of berth allocation (BAP) + quay-crane scheduling (QCASP) for a container terminal handling ~16 vessels/day. Solved via a compact continuous-time MILP with Lagrangian decomposition intuition; validated in simulation.

[![Technique](https://img.shields.io/badge/Technique-MILP%20BAP%2BQCASP-blue)]()
[![Domain](https://img.shields.io/badge/Domain-Port%20Logistics-teal)]()

## Problem Statement
An 8-berth, 14-crane terminal processes 12–18 vessels/day. Sequential FCFS scheduling leaves berths idle 14% of the time and produces average turnaround of 18+ hours. We need joint berth + crane assignment that minimizes weighted turnaround while respecting crane non-crossing, vessel compatibility, and MTBF windows.

## Key Results

| Metric | FCFS Baseline | Joint MILP | Delta |
|--------|--------------|-----------|-------|
| Avg vessel turnaround (h) | ~18.4 | ~14.3 | **−22%** |
| P95 turnaround (h) | ~28.1 | ~20.6 | **−27%** |
| Berth idle % | 14% | 8% | **−43%** |

## How to Run
```bash
pip install -r ../../requirements.txt
cd src
python main.py
```

## Resume Bullet
> Designed a joint BAP + QCASP MILP for a container terminal; reduced average vessel turnaround **22%** and P95 turnaround **27%** vs FCFS baseline, validated across simulated vessel traffic with stochastic arrivals.
