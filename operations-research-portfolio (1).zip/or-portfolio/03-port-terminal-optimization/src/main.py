"""
Project 3: Container Terminal Operations Optimization
main.py — Runs baseline FCFS vs joint BAP-QCASP optimizer.
"""
import os, sys, time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE    = os.path.dirname(__file__)
RESULTS = os.path.join(HERE, "..", "results")
os.makedirs(RESULTS, exist_ok=True)

# ── Domain objects ────────────────────────────────────────────────
from dataclasses import dataclass
from typing import List, Dict, Optional

@dataclass
class Berth:
    bid: int; length_m: int; deep: bool

@dataclass
class Crane:
    cid: int; moves_per_hour: float=28.0; mtbf_h: float=380.0

@dataclass
class Vessel:
    vid: int; eta_h: float; length_m: int; deep: bool
    moves: int; importance: float=1.0


def build_scenario(seed=11, horizon_days=7, vessels_per_day=14.0) -> Dict:
    rng = np.random.default_rng(seed)
    berths = [
        Berth(0,400,True), Berth(1,400,True), Berth(2,350,True), Berth(3,300,True),
        Berth(4,300,False),Berth(5,250,False),Berth(6,250,False),Berth(7,200,False),
    ]
    cranes = [Crane(c) for c in range(14)]
    h = horizon_days*24
    n = int(rng.poisson(vessels_per_day*horizon_days))
    etas = np.sort(rng.uniform(0,h,n))
    vessels = []
    for v,eta in enumerate(etas):
        sc = str(rng.choice(["mega","large","mid","small"],p=[0.15,0.30,0.35,0.20]))
        if   sc=="mega":  L,d,m=380,True, int(rng.normal(2400,250))
        elif sc=="large": L,d,m=320,True, int(rng.normal(1700,200))
        elif sc=="mid":   L,d,m=270,False,int(rng.normal(1100,150))
        else:             L,d,m=200,False,int(rng.normal(550,80))
        imp=float(rng.choice([1.0,1.5,2.0],p=[0.8,0.15,0.05]))
        vessels.append(Vessel(v,float(eta),L,bool(d),max(int(m),200),imp))
    return {"berths":berths,"cranes":cranes,"vessels":vessels,"horizon_h":h}


def compat(berths, vessels):
    return {v.vid:[b.bid for b in berths if b.length_m>=v.length_m and (b.deep or not v.deep)]
            for v in vessels}


# ── Baseline: FCFS sequential ─────────────────────────────────────
def fcfs(sc):
    import pulp
    berths=sc["berths"]; vessels=sc["vessels"]; cranes=sc["cranes"]
    mph=cranes[0].moves_per_hour
    free={b.bid:0.0 for b in berths}
    comp=compat(berths,vessels)
    asgn={}
    for v in sorted(vessels,key=lambda v:v.eta_h):
        cands=[b for b in berths if b.bid in comp[v.vid]]
        if not cands: continue
        best=min(cands,key=lambda b:max(free[b.bid],v.eta_h))
        s=max(free[best.bid],v.eta_h)
        f=s+v.moves/(2*mph)
        asgn[v.vid]={"berth":best.bid,"start_h":s,"finish_h":f,"n_cranes":2}
        free[best.bid]=f
    return {"assignment":asgn}


# ── Optimized: joint MILP (compact continuous-time) ───────────────
def optimized(sc, time_limit=60):
    try:
        import pulp
    except ImportError:
        return fcfs(sc)

    berths=sc["berths"]; vessels=sc["vessels"]; cranes=sc["cranes"]
    mph=cranes[0].moves_per_hour; M=sc["horizon_h"]+96
    comp_map=compat(berths,vessels)
    K=[1,2,3,4]

    prob=pulp.LpProblem("bap_qcasp",pulp.LpMinimize)
    x={(v.vid,b.bid):pulp.LpVariable(f"x_{v.vid}_{b.bid}",cat="Binary")
       for v in vessels for b in berths if b.bid in comp_map[v.vid]}
    s={v.vid:pulp.LpVariable(f"s_{v.vid}",lowBound=v.eta_h) for v in vessels}
    f={v.vid:pulp.LpVariable(f"f_{v.vid}",lowBound=0) for v in vessels}
    z={(v.vid,k):pulp.LpVariable(f"z_{v.vid}_{k}",cat="Binary") for v in vessels for k in K}

    for v in vessels:
        prob+=pulp.lpSum(z[v.vid,k] for k in K)==1
        prob+=f[v.vid]==s[v.vid]+pulp.lpSum((v.moves/(k*mph))*z[v.vid,k] for k in K)
        prob+=pulp.lpSum(x[v.vid,b.bid] for b in berths if b.bid in comp_map[v.vid])==1

    by_eta=sorted(vessels,key=lambda v:v.eta_h)
    for i,v1 in enumerate(by_eta):
        for v2 in by_eta[i+1:]:
            if v2.eta_h-v1.eta_h>24: continue
            for b in berths:
                if b.bid not in comp_map[v1.vid] or b.bid not in comp_map[v2.vid]: continue
                prob+=s[v2.vid]>=f[v1.vid]-M*(2-x[v1.vid,b.bid]-x[v2.vid,b.bid])

    prob+=pulp.lpSum(v.importance*(f[v.vid]-v.eta_h) for v in vessels)
    prob.solve(pulp.PULP_CBC_CMD(msg=False,timeLimit=time_limit))

    asgn={}
    for v in vessels:
        b_a=next((b.bid for b in berths if b.bid in comp_map[v.vid]
                  and x[v.vid,b.bid].value() and x[v.vid,b.bid].value()>0.5),None)
        if b_a is None: continue
        nk=next((k for k in K if z[v.vid,k].value() and z[v.vid,k].value()>0.5),2)
        asgn[v.vid]={"berth":b_a,"start_h":float(s[v.vid].value()),
                     "finish_h":float(f[v.vid].value()),"n_cranes":int(nk)}
    return {"assignment":asgn}


def metrics(sc, plan):
    a=plan["assignment"]; vessels=sc["vessels"]
    if not a: return {}
    ta=np.array([a[v.vid]["finish_h"]-v.eta_h for v in vessels if v.vid in a])
    busy={b.bid:0.0 for b in sc["berths"]}
    for info in a.values(): busy[info["berth"]]+=info["finish_h"]-info["start_h"]
    idle=1-(sum(busy.values())/(sc["horizon_h"]*len(sc["berths"])))
    return {"n_served":len(a),"avg_turnaround_h":round(float(ta.mean()),2),
            "p95_turnaround_h":round(float(np.percentile(ta,95)),2),
            "berth_idle_pct":round(float(idle),3),
            "avg_cranes":round(float(np.mean([i["n_cranes"] for i in a.values()])),2)}


def make_plots(m_base, m_opt):
    fig,axes=plt.subplots(1,3,figsize=(12,4))
    fig.suptitle("Project 3 — Container Terminal Optimization",fontsize=13,fontweight="bold")
    keys=["avg_turnaround_h","p95_turnaround_h","berth_idle_pct"]
    labels=["Avg turnaround (h)","P95 turnaround (h)","Berth idle %"]
    for ax,(k,lbl) in zip(axes,zip(keys,labels)):
        vals=[m_base.get(k,0),m_opt.get(k,0)]
        ax.bar(["Baseline","Optimized"],vals,color=["#F09595","#5DCAA5"],alpha=0.85)
        for i,v in enumerate(vals): ax.text(i,v*1.02,f"{v:.2f}",ha="center",fontsize=10)
        ax.set_title(lbl); ax.set_ylabel(lbl)
    plt.tight_layout()
    out=os.path.join(RESULTS,"port_results.png")
    plt.savefig(out,dpi=120,bbox_inches="tight"); plt.close()
    print(f"  Plot → {out}")


def main():
    print("="*60); print("Project 3 — Container Terminal Optimization"); print("="*60)
    sc=build_scenario(horizon_days=7)
    print(f"Vessels: {len(sc['vessels'])}  Berths: {len(sc['berths'])}  Cranes: {len(sc['cranes'])}")
    print("\n[Baseline] FCFS …",end=" ",flush=True)
    t0=time.time(); base=fcfs(sc); t1=time.time()
    mb=metrics(sc,base); print(f"done {t1-t0:.1f}s  |  {mb}")
    print("[Optimized] Joint MILP …",end=" ",flush=True)
    t0=time.time(); opt=optimized(sc,time_limit=60); t1=time.time()
    mo=metrics(sc,opt); print(f"done {t1-t0:.1f}s  |  {mo}")
    print(f"\n  Turnaround delta: {(mo['avg_turnaround_h']-mb['avg_turnaround_h'])/mb['avg_turnaround_h']*100:+.1f}%")
    make_plots(mb,mo)
    pd.DataFrame([{"policy":"baseline",**mb},{"policy":"optimized",**mo}]).to_csv(
        os.path.join(RESULTS,"results.csv"),index=False)

if __name__=="__main__":
    main()
