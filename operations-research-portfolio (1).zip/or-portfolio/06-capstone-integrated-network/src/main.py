"""
main.py — Project 6: Integrated Resilient Supply Network
Two-stage stochastic programming + Bayesian demand forecasting.
Stage 1: facility location & capacity (here-and-now decisions)
Stage 2: flow & routing per scenario (wait-and-see decisions)
"""
import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE    = os.path.dirname(__file__)
RESULTS = os.path.join(HERE, "..", "results")
os.makedirs(RESULTS, exist_ok=True)


# ── Scenario generation ───────────────────────────────────────────
def build_network(seed=77):
    rng = np.random.default_rng(seed)
    suppliers = [{"sid":i,"cap":rng.integers(500,1500),"cost_per_unit":rng.uniform(8,15)} for i in range(4)]
    dcs       = [{"did":i,"fixed":rng.uniform(80000,200000),"cap":rng.integers(1000,3000)} for i in range(5)]
    markets   = [{"mid":i,"base_demand":rng.uniform(200,800),"cv":rng.uniform(0.1,0.4)} for i in range(6)]
    ship_sd   = np.random.default_rng(seed+1).uniform(5,50,size=(4,5))
    ship_dm   = np.random.default_rng(seed+2).uniform(3,30,size=(5,6))
    return {"suppliers":suppliers,"dcs":dcs,"markets":markets,
            "ship_sd":ship_sd,"ship_dm":ship_dm,"rng":rng}


def generate_scenarios(sc, n_scenarios=20):
    """Generate demand + disruption scenarios."""
    rng = sc["rng"]; scenarios=[]
    for s in range(n_scenarios):
        demand = np.array([
            max(0, rng.normal(m["base_demand"], m["cv"]*m["base_demand"]))
            for m in sc["markets"]
        ])
        # Disruption: 20% chance a random supplier is unavailable
        disrupted_sup = int(rng.integers(4)) if rng.random()<0.20 else -1
        # Disruption: 10% chance a DC capacity halved
        disrupted_dc  = int(rng.integers(5)) if rng.random()<0.10 else -1
        prob = 1.0/n_scenarios
        scenarios.append({"s":s,"demand":demand,
                           "disrupted_sup":disrupted_sup,"disrupted_dc":disrupted_dc,"prob":prob})
    return scenarios


# ── Bayesian demand forecasting (simple conjugate update) ─────────
def bayesian_forecast(sc, obs_data=None):
    """Update demand priors with observed data using conjugate Normal-Normal."""
    results=[]
    for m in sc["markets"]:
        mu0   = m["base_demand"]          # prior mean
        tau0  = mu0 * 0.30                # prior std
        if obs_data is not None and m["mid"] < len(obs_data):
            obs   = np.array(obs_data[m["mid"]])
            n     = len(obs)
            sigma = m["cv"] * m["base_demand"]
            # Conjugate update
            tau_n = 1 / (1/tau0**2 + n/sigma**2)
            mu_n  = tau_n * (mu0/tau0**2 + obs.mean()*n/sigma**2)
        else:
            mu_n, tau_n = mu0, tau0
        results.append({"market":m["mid"],"prior_mean":round(mu0,1),
                         "posterior_mean":round(float(mu_n),1),"posterior_std":round(float(np.sqrt(tau_n)),2)})
    return pd.DataFrame(results)


# ── Stage 2: flow optimisation for one scenario ───────────────────
def solve_stage2(sc, sc_data, open_dcs):
    """LP flow optimisation for given scenario and open DCs."""
    try:
        import pulp
    except ImportError:
        total = sum(sc_data["demand"]) * 12
        return {"cost": total, "unmet": 0}

    suppliers=sc["suppliers"]; dcs=sc["dcs"]; markets=sc["markets"]
    ship_sd=sc["ship_sd"]; ship_dm=sc["ship_dm"]
    demand=sc_data["demand"]; dis_sup=sc_data["disrupted_sup"]; dis_dc=sc_data["disrupted_dc"]

    prob=pulp.LpProblem("s2",pulp.LpMinimize)
    x={(i,j):pulp.LpVariable(f"x_{i}_{j}",lowBound=0) for i in range(4) for j in range(5)}
    y={(j,k):pulp.LpVariable(f"y_{j}_{k}",lowBound=0) for j in range(5) for k in range(6)}
    u={k:pulp.LpVariable(f"u_{k}",lowBound=0) for k in range(6)}

    # Cost: shipping + penalty for unmet demand
    prob += (pulp.lpSum(ship_sd[i,j]*x[i,j] for i in range(4) for j in range(5)) +
             pulp.lpSum(ship_dm[j,k]*y[j,k] for j in range(5) for k in range(6)) +
             pulp.lpSum(200*u[k] for k in range(6)))

    for i,s in enumerate(suppliers):
        cap = 0 if i==dis_sup else s["cap"]
        prob += pulp.lpSum(x[i,j] for j in range(5)) <= cap

    for j in range(5):
        if j not in open_dcs: 
            for i in range(4): prob += x[i,j] == 0
            for k in range(6): prob += y[j,k] == 0
            continue
        dc_cap = dcs[j]["cap"]*(0.5 if j==dis_dc else 1.0)
        inflow = pulp.lpSum(x[i,j] for i in range(4))
        prob += inflow <= dc_cap
        prob += pulp.lpSum(y[j,k] for k in range(6)) == inflow

    for k in range(6):
        prob += pulp.lpSum(y[j,k] for j in range(5)) + u[k] >= demand[k]

    prob.solve(pulp.PULP_CBC_CMD(msg=False))
    return {"cost": pulp.value(prob.objective) or 0,
            "unmet": sum(u[k].value() or 0 for k in range(6))}


# ── Stage 1: facility location ───────────────────────────────────
def solve_two_stage(sc, scenarios):
    """Evaluate all DC combinations, pick minimum expected cost."""
    from itertools import combinations
    best_cost=float("inf"); best_config=None; best_results=[]
    # Try opening 3 of 5 DCs (enumerate for small instance)
    for open_dcs in combinations(range(5), 3):
        open_dcs_set = set(open_dcs)
        fixed_cost   = sum(sc["dcs"][j]["fixed"] for j in open_dcs_set)
        exp_cost     = fixed_cost
        stage2_res   = []
        for scen in scenarios:
            r = solve_stage2(sc, scen, open_dcs_set)
            exp_cost += scen["prob"] * r["cost"]
            stage2_res.append(r)
        if exp_cost < best_cost:
            best_cost=exp_cost; best_config=open_dcs; best_results=stage2_res
    return {"open_dcs":list(best_config),"expected_cost":round(best_cost,0),"stage2":best_results}


def make_plots(det_cost, stoch_result, forecast_df, scenarios):
    fig,axes=plt.subplots(1,3,figsize=(13,4))
    fig.suptitle("Project 6 — Integrated Resilient Supply Network",fontsize=13,fontweight="bold")

    ax=axes[0]; ax.set_title("Expected cost comparison")
    vals=[det_cost, stoch_result["expected_cost"]]
    bars=ax.bar(["Deterministic","Stochastic"],np.array(vals)/1e6,color=["#F09595","#5DCAA5"],alpha=0.85)
    for b,v in zip(bars,np.array(vals)/1e6):
        ax.text(b.get_x()+b.get_width()/2,v+0.05,f"${v:.2f}M",ha="center",fontsize=10)
    ax.set_ylabel("Expected cost ($M)")

    ax=axes[1]; ax.set_title("Bayesian demand forecasts")
    x=np.arange(len(forecast_df))
    ax.bar(x-0.2,forecast_df["prior_mean"],0.38,label="Prior",color="#AFA9EC",alpha=0.8)
    ax.bar(x+0.2,forecast_df["posterior_mean"],0.38,label="Posterior",color="#5DCAA5",alpha=0.8)
    ax.set_xticks(x); ax.set_xticklabels([f"M{i}" for i in range(len(forecast_df))])
    ax.legend(fontsize=8); ax.set_ylabel("Demand units")

    ax=axes[2]; ax.set_title("Scenario cost distribution")
    costs=[r["cost"] for r in stoch_result["stage2"]]
    ax.hist(np.array(costs)/1e6,bins=8,color="#534AB7",alpha=0.8,edgecolor="white")
    ax.axvline(np.mean(costs)/1e6,color="#E24B4A",linestyle="--",
               label=f"Mean ${np.mean(costs)/1e6:.2f}M"); ax.legend(fontsize=8)
    ax.set_xlabel("Scenario cost ($M)")

    plt.tight_layout()
    out=os.path.join(RESULTS,"capstone_results.png")
    plt.savefig(out,dpi=120,bbox_inches="tight"); plt.close(); print(f"  Plot → {out}")


def main():
    print("="*60); print("Project 6 — Integrated Resilient Supply Network"); print("="*60)
    sc = build_network()
    print(f"Suppliers:{len(sc['suppliers'])}  DCs:{len(sc['dcs'])}  Markets:{len(sc['markets'])}")

    print("\n[Step 1] Bayesian demand forecasting …",end=" ",flush=True)
    obs = [list(np.random.default_rng(42+m).normal(sc["markets"][m]["base_demand"],
                 sc["markets"][m]["cv"]*sc["markets"][m]["base_demand"],8))
           for m in range(len(sc["markets"]))]
    fc = bayesian_forecast(sc, obs); print("done")
    print(fc.to_string(index=False))

    print("\n[Step 2] Generating 20 scenarios …",end=" ",flush=True)
    scenarios = generate_scenarios(sc, n_scenarios=20); print("done")

    print("[Step 3] Deterministic baseline (all DCs open) …",end=" ",flush=True)
    det_avg = np.mean([solve_stage2(sc,s,{0,1,2,3,4})["cost"] for s in scenarios])
    det_fixed = sum(d["fixed"] for d in sc["dcs"])
    det_cost = det_avg + det_fixed; print(f"done  Expected=${det_cost/1e6:.2f}M")

    print("[Step 4] Two-stage stochastic program (best 3-DC config) …",end=" ",flush=True)
    result = solve_two_stage(sc, scenarios); print("done")
    print(f"  Best config: DCs {result['open_dcs']}  Expected=${result['expected_cost']/1e6:.2f}M")
    print(f"  Cost reduction: {(result['expected_cost']-det_cost)/det_cost*100:+.1f}%")

    make_plots(det_cost, result, fc, scenarios)
    fc.to_csv(os.path.join(RESULTS,"bayesian_forecast.csv"),index=False)
    print(f"\nOutputs → {RESULTS}")


if __name__=="__main__":
    main()
