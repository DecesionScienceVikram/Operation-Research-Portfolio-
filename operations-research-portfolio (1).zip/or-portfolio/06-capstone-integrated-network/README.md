# Project 6 — Capstone: Integrated Resilient Supply Network

> Two-stage stochastic programming that ties together the upstream supply decisions (Project 4), distribution routing (Projects 2 & 3), and scheduling constraints (Project 1) into a single resilient network optimization. Includes Bayesian demand forecasting and scenario-based disruption analysis.

[![Technique](https://img.shields.io/badge/Technique-Stochastic%20Programming%20%2B%20Bayesian-blue)]()
[![Domain](https://img.shields.io/badge/Domain-Integrated%20Network-teal)]()

## Problem Statement
Each upstream project optimizes its own domain. The capstone asks: what is the globally optimal network configuration under demand uncertainty and supply disruptions (e.g., port closure, factory shutdown)? A two-stage stochastic program decides facility locations and capacities in stage 1, then optimizes flows and schedules in stage 2 for each scenario.

## Key Results

| Metric | Deterministic | Stochastic | Delta |
|--------|--------------|-----------|-------|
| Expected total cost | $12.4M | $11.1M | **−10.5%** |
| Cost under disruption (P90) | $18.2M | $14.3M | **−21%** |
| Network resilience score | 0.61 | 0.84 | **+38%** |

## How to Run
```bash
pip install -r ../../requirements.txt
cd src
python main.py
```

## Resume Bullet
> Designed a two-stage stochastic program integrating procurement, distribution, and scheduling decisions across a 6-node supply network; reduced expected cost **10.5%** and P90 disruption cost **21%** vs deterministic planning.
