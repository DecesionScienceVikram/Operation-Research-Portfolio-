# Project 1 — Digital Twin-Driven Multi-Agent Manufacturing Optimization

> Online production regulation for a reconfigurable manufacturing system where humans and robots share tasks. A SimPy digital twin mirrors the floor every 60 seconds; a rolling-horizon MILP assigns jobs; Q-learning agents per station shape priorities.

[![Technique](https://img.shields.io/badge/Technique-MILP%20%2B%20RL-purple)]()
[![Domain](https://img.shields.io/badge/Domain-Manufacturing-teal)]()

## Problem Statement

A reconfigurable manufacturing line switches between 3 product families. Static schedules go stale within minutes as task times vary (log-normal σ=0.10), robots are retasked, and operator fatigue builds. The system needs online re-optimization every 60 seconds without halting production — and must protect operator ergonomics (ISO 11228-3 compliance).

## Solution Architecture

```
Physical Floor → Digital Twin (SimPy) → Rolling-Horizon MILP (PuLP/CBC) → Dispatch
                                              ↑ priority bids
                                    6 × Q-Learning Agents (one per station)
```

## Key Results

| Metric | Baseline | Optimized | Delta |
|--------|----------|-----------|-------|
| Throughput (jobs/shift) | 407 | 408 | Parity |
| Peak fatigue index | 0.66 | **0.23** | **−65%** |
| Ending WIP | 2.33 | 2.00 | −14% |
| Energy (kWh/shift) | 36.4 | 37.2 | +2% |
| Ergonomic incidents | 2.3/shift | 0.1/shift | −96% |
| MILP solve time | — | 1.84 s | <2 s |

## How to Run

```bash
pip install -r ../../requirements.txt
cd src
python main.py
```

## Files

| File | Purpose |
|------|---------|
| `src/data_generator.py` | Synthetic scenario: stations, jobs, operators |
| `src/digital_twin.py` | SimPy DES — live floor state mirror |
| `src/milp_optimizer.py` | Rolling-horizon MILP (PuLP + CBC) |
| `src/marl_agent.py` | Tabular Q-learning agent per station |
| `src/main.py` | End-to-end runner + comparison table |
| `docs/project_charter.md` | Scope, milestones, RACI, risk register |
| `docs/executive_summary.md` | 1-page stakeholder summary |

## Resume Bullet

> Designed a digital-twin MILP + multi-agent RL framework for a reconfigurable manufacturing line; reduced operator peak fatigue **65%** while holding throughput parity at saturated load, projecting **$281K annual benefit** for a 250-person plant.
