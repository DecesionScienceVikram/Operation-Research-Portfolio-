"""
digital_twin.py — Project 1
SimPy discrete-event digital twin that mirrors the physical floor.
Emits a state snapshot every 60-second tick consumed by the MILP optimizer.
"""
import simpy
import numpy as np
from collections import deque
from typing import Dict, List, Optional


class DigitalTwin:
    """
    Live state model. Exposes every tick:
      station_queue[sid]    : deque of waiting job IDs
      station_busy[sid]     : bool
      operator_fatigue[hid] : float in [0, 1]
      completed_jobs        : list of (jid, finish_time)
      energy_kwh            : cumulative kWh
    """
    FATIGUE_DECAY = 0.92          # ρ — 8% recovery per tick
    FATIGUE_LOAD  = {"human": 0.06, "robot": 0.00, "collab": 0.03}

    def __init__(self, scenario: Dict, rng: Optional[np.random.Generator] = None):
        self.scn = scenario
        self.env = simpy.Environment()
        self.rng = rng or np.random.default_rng(0)

        self.station_queue    = {s.sid: deque() for s in scenario["stations"]}
        self.station_busy     = {s.sid: False    for s in scenario["stations"]}
        self.station_resources= {s.sid: simpy.Resource(self.env, capacity=1)
                                 for s in scenario["stations"]}
        self.operator_fatigue = {o.hid: 0.0 for o in scenario["operators"]}
        self.completed_jobs: List = []
        self.energy_kwh: float = 0.0
        self.reconfig_count: int = 0

        self.env.process(self._arrival_driver())

    # ── arrivals ──────────────────────────────────────────────────
    def _arrival_driver(self):
        for job in self.scn["jobs"]:
            yield self.env.timeout(max(0.0, job.arrival - self.env.now))
            sid = self._dispatch_default(job)
            if sid is not None:
                self.station_queue[sid].append(job.jid)

    def _dispatch_default(self, job) -> Optional[int]:
        cands = [s for s in self.scn["stations"] if job.family in s.capabilities]
        if not cands:
            return None
        return min(cands, key=lambda s: len(self.station_queue[s.sid])).sid

    # ── optimizer-driven assignment ────────────────────────────────
    def schedule_processing(self, sid: int, jid: int, mode: str,
                             operator_id: Optional[int] = None):
        self.env.process(self._run_job(sid, jid, mode, operator_id))

    def _run_job(self, sid, jid, mode, operator_id):
        station = next(s for s in self.scn["stations"] if s.sid == sid)
        job     = next(j for j in self.scn["jobs"]     if j.jid == jid)
        if job.family not in station.base_proc_time:
            return
        with self.station_resources[sid].request() as req:
            yield req
            self.station_busy[sid] = True
            base  = station.base_proc_time[job.family]
            mult  = {"human": 1.10, "robot": 0.90, "collab": 0.80}[mode]
            if operator_id is not None and mode != "robot":
                op   = next(o for o in self.scn["operators"] if o.hid == operator_id)
                mult *= op.skill * (1.0 + 0.4 * op.fatigue)
            noise    = float(self.rng.lognormal(0.0, 0.10))
            duration = base * mult * noise
            yield self.env.timeout(duration)
            self.station_busy[sid] = False
            self.energy_kwh += station.energy_kw[mode] * (duration / 60.0)
            if operator_id is not None and mode != "robot":
                f = self.operator_fatigue[operator_id]
                self.operator_fatigue[operator_id] = min(
                    1.0, self.FATIGUE_DECAY * f + self.FATIGUE_LOAD[mode])
            self.completed_jobs.append((jid, float(self.env.now)))

    # ── state snapshot ─────────────────────────────────────────────
    def snapshot(self) -> Dict:
        return {
            "now":       float(self.env.now),
            "queues":    {sid: list(q) for sid, q in self.station_queue.items()},
            "busy":      dict(self.station_busy),
            "fatigue":   dict(self.operator_fatigue),
            "energy_kwh":self.energy_kwh,
            "completed": len(self.completed_jobs),
            "reconfigs": self.reconfig_count,
        }

    def step(self, minutes: float = 1.0):
        self.env.run(until=self.env.now + minutes)
