"""
data_generator.py — Project 1: Digital Twin Manufacturing
Generates a realistic 6-station, 3-product-family RMS scenario.
"""
import numpy as np
import pandas as pd
from dataclasses import dataclass, asdict, field
from typing import List, Dict


@dataclass
class Station:
    sid: int
    capabilities: List[str]
    base_proc_time: Dict[str, float]
    energy_kw: Dict[str, float]
    reconfig_cost: float = 25.0


@dataclass
class Job:
    jid: int
    family: str
    arrival: float
    requires_human: bool = False
    priority: float = 1.0


@dataclass
class Operator:
    hid: int
    skill: float = 1.0
    fatigue: float = 0.0


def build_scenario(seed: int = 42, shift_minutes: int = 480) -> Dict:
    rng = np.random.default_rng(seed)
    families = ["A", "B", "C"]

    stations: List[Station] = []
    for sid in range(6):
        n_fam = rng.integers(2, 4)
        caps = list(set(rng.choice(families, size=n_fam, replace=True)))
        base = {f: float(rng.uniform(2.0, 4.5)) for f in caps}
        energy = {"human": 0.5, "robot": 1.8, "collab": 1.3}
        stations.append(Station(sid=sid, capabilities=caps,
                                base_proc_time=base, energy_kw=energy))

    arrival_rate = 0.85
    n_jobs = int(rng.poisson(arrival_rate * shift_minutes))
    arrivals = np.sort(rng.uniform(0, shift_minutes, size=n_jobs))
    jobs: List[Job] = []
    for j, t in enumerate(arrivals):
        fam = str(rng.choice(families, p=[0.40, 0.35, 0.25]))
        precision = (fam == "A") and (rng.random() < 0.15)
        jobs.append(Job(jid=j, family=fam, arrival=float(t),
                        requires_human=precision,
                        priority=float(rng.choice([1.0, 1.0, 1.5, 2.0]))))

    operators = [Operator(hid=h, skill=float(rng.uniform(0.85, 1.15)))
                 for h in range(3)]

    return {
        "families": families,
        "stations": stations,
        "jobs": jobs,
        "operators": operators,
        "shift_minutes": shift_minutes,
        "n_robots": 4,
    }


def to_dataframes(scenario: Dict) -> Dict[str, pd.DataFrame]:
    return {
        "stations": pd.DataFrame([asdict(s) for s in scenario["stations"]]),
        "jobs":     pd.DataFrame([asdict(j) for j in scenario["jobs"]]),
        "operators":pd.DataFrame([asdict(o) for o in scenario["operators"]]),
    }


if __name__ == "__main__":
    sc = build_scenario()
    print(f"Stations : {len(sc['stations'])}")
    print(f"Jobs     : {len(sc['jobs'])}")
    print(f"Operators: {len(sc['operators'])}")
    dfs = to_dataframes(sc)
    print(dfs["jobs"].head())
