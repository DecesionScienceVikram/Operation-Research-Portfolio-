"""
milp_optimizer.py — Project 1
Rolling-horizon MILP: assigns jobs to stations and modes every tick.
Solver: PuLP + open-source CBC (no commercial licence needed).
"""
from typing import Dict, List, Tuple, Optional
import pulp


def solve_assignment(snapshot: Dict, scenario: Dict,
                     fatigue_cap: float = 0.85,
                     time_limit: int = 5) -> Dict[int, Tuple[int, str, Optional[int]]]:
    """
    Returns {station_id: (job_id, mode, operator_id_or_None)}.

    Objective: maximise reward per assignment.
      reward = 20 + 3*priority - 0.5*proc_time - 1.5*energy - 5*fatigue
    The +20 constant ensures the solver always prefers assigning over doing nothing.
    """
    stations  = scenario["stations"]
    operators = scenario["operators"]
    jobs_by_id= {j.jid: j for j in scenario["jobs"]}

    # Build candidate (station, job, mode, operator) tuples
    candidates = []
    for s in stations:
        if snapshot["busy"][s.sid]:
            continue
        queue = snapshot["queues"][s.sid]
        if not queue:
            continue
        for jid in list(queue)[:3]:            # consider top-3 in queue
            job = jobs_by_id.get(jid)
            if job is None or job.family not in s.capabilities:
                continue
            modes = ["human", "collab"] if job.requires_human else ["human", "robot", "collab"]
            for m in modes:
                if m == "robot":
                    candidates.append((s.sid, jid, m, None))
                else:
                    for o in operators:
                        if snapshot["fatigue"].get(o.hid, 0) < fatigue_cap:
                            candidates.append((s.sid, jid, m, o.hid))

    if not candidates:
        return {}

    prob = pulp.LpProblem("milp_assign", pulp.LpMaximize)
    x    = {c: pulp.LpVariable(f"x_{c}", cat="Binary") for c in candidates}

    def reward(c):
        sid, jid, m, hid = c
        st   = next(s for s in stations if s.sid == sid)
        job  = jobs_by_id[jid]
        base = st.base_proc_time[job.family]
        mult = {"human": 1.10, "robot": 0.90, "collab": 0.80}[m]
        proc = base * mult
        en   = st.energy_kw[m] * (proc / 60.0)
        fat  = 5.0 * snapshot["fatigue"].get(hid, 0) if hid is not None else 0.0
        return 20.0 + 3.0 * job.priority - 0.5 * proc - 1.5 * en - fat

    prob += pulp.lpSum(reward(c) * x[c] for c in candidates)

    # C1: each job assigned at most once
    by_job = {}
    for c in candidates:
        by_job.setdefault(c[1], []).append(c)
    for jid, cs in by_job.items():
        prob += pulp.lpSum(x[c] for c in cs) <= 1, f"job_{jid}"

    # C2: one job per station per tick
    by_st = {}
    for c in candidates:
        by_st.setdefault(c[0], []).append(c)
    for sid, cs in by_st.items():
        prob += pulp.lpSum(x[c] for c in cs) <= 1, f"st_{sid}"

    # C3: one job per operator
    by_op = {}
    for c in candidates:
        if c[3] is not None:
            by_op.setdefault(c[3], []).append(c)
    for hid, cs in by_op.items():
        prob += pulp.lpSum(x[c] for c in cs) <= 1, f"op_{hid}"

    prob.solve(pulp.PULP_CBC_CMD(msg=False, timeLimit=time_limit))

    return {
        c[0]: (c[1], c[2], c[3])
        for c, var in x.items()
        if var.value() is not None and var.value() > 0.5
    }
