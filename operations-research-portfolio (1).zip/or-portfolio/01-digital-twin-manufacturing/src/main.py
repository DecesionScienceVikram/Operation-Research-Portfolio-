"""
main.py — Project 1: Digital Twin Manufacturing Optimization
Compares BASELINE (static dispatch) vs MILP-MARL (optimized) policies.
Runs N replications and prints a comparison table + saves CSV.

Usage:
    python main.py
    python main.py --reps 10
"""
import os, sys, argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Allow running from any directory
sys.path.insert(0, os.path.dirname(__file__))
from data_generator  import build_scenario
from digital_twin    import DigitalTwin
from milp_optimizer  import solve_assignment
from marl_agent      import StationAgent

HERE    = os.path.dirname(__file__)
RESULTS = os.path.join(HERE, "..", "results")
os.makedirs(RESULTS, exist_ok=True)


# ── BASELINE policy ───────────────────────────────────────────────
def run_baseline(seed: int) -> dict:
    sc   = build_scenario(seed=seed)
    twin = DigitalTwin(sc, rng=np.random.default_rng(seed))
    for _ in range(sc["shift_minutes"]):
        snap = twin.snapshot()
        for sid, q in snap["queues"].items():
            if q and not snap["busy"][sid]:
                jid  = q[0]
                job  = next(j for j in sc["jobs"] if j.jid == jid)
                mode = "human" if job.requires_human else "robot"
                hid  = sc["operators"][0].hid if mode == "human" else None
                twin.station_queue[sid].popleft()
                twin.schedule_processing(sid, jid, mode, hid)
        twin.step(1.0)
    return _metrics(twin, sc, "baseline")


# ── MILP-MARL policy ──────────────────────────────────────────────
def run_milp_marl(seed: int) -> dict:
    sc     = build_scenario(seed=seed)
    twin   = DigitalTwin(sc, rng=np.random.default_rng(seed))
    agents = {s.sid: StationAgent(s.sid, seed=seed) for s in sc["stations"]}
    prev   = 0

    for tick in range(sc["shift_minutes"]):
        snap = twin.snapshot()
        for sid, ag in agents.items():
            ag.act(StationAgent.encode(snap, sid))

        decisions = solve_assignment(snap, sc, fatigue_cap=0.85, time_limit=2)
        for sid, (jid, mode, hid) in decisions.items():
            try:
                twin.station_queue[sid].remove(jid)
            except ValueError:
                continue
            twin.schedule_processing(sid, jid, mode, hid)

        twin.step(1.0)
        done     = len(twin.completed_jobs)
        new_done = done - prev
        prev     = done
        snap2    = twin.snapshot()
        peak_fat = max(snap2["fatigue"].values()) if snap2["fatigue"] else 0
        reward   = new_done - 2.0 * max(0, peak_fat - 0.80)
        for sid, ag in agents.items():
            ns = StationAgent.encode(snap2, sid)
            ag.update(reward, ns, done=(tick == sc["shift_minutes"] - 1))
            ag.decay_eps()

    return _metrics(twin, sc, "milp_marl")


# ── helpers ───────────────────────────────────────────────────────
def _metrics(twin: DigitalTwin, sc: dict, label: str) -> dict:
    end_wip  = sum(len(twin.station_queue[s.sid]) for s in sc["stations"])
    peak_fat = max(twin.operator_fatigue.values()) if twin.operator_fatigue else 0
    return {
        "policy":      label,
        "throughput":  len(twin.completed_jobs),
        "peak_fatigue":round(float(peak_fat), 4),
        "energy_kwh":  round(float(twin.energy_kwh), 2),
        "ending_wip":  int(end_wip),
        "reconfigs":   twin.reconfig_count,
    }


def make_plots(df: pd.DataFrame):
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    fig.suptitle("Project 1 — Baseline vs MILP-MARL", fontsize=13, fontweight="bold")

    metrics = [
        ("throughput",  "Throughput (jobs/shift)", False),
        ("peak_fatigue","Peak Fatigue Index",       False),
        ("energy_kwh",  "Energy (kWh/shift)",       False),
    ]
    colors = {"baseline": "#AFA9EC", "milp_marl": "#5DCAA5"}

    for ax, (col, title, _) in zip(axes, metrics):
        for policy, grp in df.groupby("policy"):
            means = grp[col].values
            x     = np.arange(len(means))
            ax.bar(x + (0.2 if policy == "milp_marl" else -0.2),
                   means, width=0.38, label=policy.replace("_", "-"),
                   color=colors[policy], alpha=0.85)
        ax.set_title(title, fontsize=11)
        ax.set_xlabel("Replication")
        ax.set_xticks(np.arange(df.groupby("policy").size().max()))
        ax.legend(fontsize=9)
        if col == "peak_fatigue":
            ax.axhline(0.85, color="#EF9F27", linestyle="--", linewidth=1.2, label="Cap 0.85")

    plt.tight_layout()
    out = os.path.join(RESULTS, "comparison_plots.png")
    plt.savefig(out, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"  Plot saved → {out}")


# ── main ──────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=3)
    args = parser.parse_args()

    print("=" * 65)
    print("Project 1 — Digital Twin Manufacturing Optimization")
    print("=" * 65)
    print(f"Running {args.reps} replication(s) per policy …\n")

    rows = []
    for r in range(args.reps):
        print(f"  Rep {r+1}: baseline …", end=" ", flush=True)
        rows.append(run_baseline(seed=100 + r))
        print("done │ milp_marl …", end=" ", flush=True)
        rows.append(run_milp_marl(seed=100 + r))
        print("done")

    df      = pd.DataFrame(rows)
    summary = df.groupby("policy").agg(["mean", "std"]).round(3)

    df.to_csv(os.path.join(RESULTS, "raw_results.csv"), index=False)
    summary.to_csv(os.path.join(RESULTS, "summary.csv"))

    print("\n" + summary.to_string())

    # Throughput delta
    base_tp = df[df["policy"] == "baseline"]["throughput"].mean()
    opt_tp  = df[df["policy"] == "milp_marl"]["throughput"].mean()
    base_fat= df[df["policy"] == "baseline"]["peak_fatigue"].mean()
    opt_fat = df[df["policy"] == "milp_marl"]["peak_fatigue"].mean()

    print(f"\n  Throughput delta  : {(opt_tp  - base_tp ) / base_tp  * 100:+.1f}%")
    print(f"  Peak fatigue delta: {(opt_fat - base_fat) / base_fat * 100:+.1f}%")

    make_plots(df)
    print(f"\nAll outputs → {RESULTS}")


if __name__ == "__main__":
    main()
