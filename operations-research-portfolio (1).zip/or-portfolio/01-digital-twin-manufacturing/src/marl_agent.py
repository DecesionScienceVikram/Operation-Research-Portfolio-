"""
marl_agent.py — Project 1
Tabular Q-learning agent (one per station).
Agents observe local state and output a priority bid fed to the MILP.
They never override hard constraints — they only shape the objective.
"""
import numpy as np
from collections import defaultdict


class StationAgent:
    """
    State  : (queue_bucket, family_mix, fatigue_bucket)
    Action : bid ∈ {-2, -1, 0, +1, +2}  added to job priority
    """
    ACTIONS = (-2, -1, 0, 1, 2)

    def __init__(self, sid: int, alpha: float = 0.10, gamma: float = 0.95,
                 eps: float = 0.20, seed: int = 0):
        self.sid   = sid
        self.alpha = alpha
        self.gamma = gamma
        self.eps   = eps
        self.q     = defaultdict(lambda: np.zeros(len(self.ACTIONS)))
        self.rng   = np.random.default_rng(seed + sid)
        self.last  = None

    @staticmethod
    def encode(snapshot: dict, sid: int) -> tuple:
        q       = snapshot["queues"][sid]
        qbucket = min(len(q) // 2, 4)
        mix     = str(q[0] % 3) if q else "0"
        max_fat = max(snapshot["fatigue"].values()) if snapshot["fatigue"] else 0.0
        fbucket = int(min(max_fat, 0.99) * 5)
        return (qbucket, mix, fbucket)

    def act(self, state: tuple) -> int:
        if self.rng.random() < self.eps:
            idx = int(self.rng.integers(len(self.ACTIONS)))
        else:
            idx = int(np.argmax(self.q[state]))
        self.last = (state, idx)
        return self.ACTIONS[idx]

    def update(self, reward: float, next_state: tuple, done: bool = False):
        if self.last is None:
            return
        state, idx = self.last
        target = reward if done else reward + self.gamma * float(np.max(self.q[next_state]))
        self.q[state][idx] += self.alpha * (target - self.q[state][idx])

    def decay_eps(self, factor: float = 0.995, floor: float = 0.02):
        self.eps = max(floor, self.eps * factor)
