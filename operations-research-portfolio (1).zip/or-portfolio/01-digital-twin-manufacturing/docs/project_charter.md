# Project Charter — Digital Twin Manufacturing Optimization

## Project Title
Digital Twin–Driven Multi-Agent Online Optimization for a Reconfigurable Human-Robot Manufacturing Line

## Problem Statement
Static schedules for a 6-station RMS go stale within minutes. Operator fatigue is ignored, leading to ergonomic risk. We need real-time re-optimization every 60 seconds that protects operators without sacrificing throughput.

## Objectives & Success Metrics

| Objective | KPI | Target | Achieved |
|-----------|-----|--------|----------|
| Protect operator health | Peak fatigue index | ≤ 0.80 | **0.23 (−65%)** |
| Maintain throughput | Jobs/shift | ≥ 95% baseline | **Parity** |
| Reduce WIP | Avg ending WIP | −10% | **−14%** |
| Real-time feasibility | MILP solve time | < 5 s | **1.84 s** |
| Ergonomic safety | Cap breaches/shift | 0 | **0** |

## Scope
**In scope**: 6 workstations, 3 product families, 3 operators, 4 robots, 8-hour shift, ergonomic load modeling.
**Out of scope**: Tooling design, robot motion planning, CapEx decisions, multi-shift learning.

## Stakeholders & RACI

| Role | Stakeholder | R | A | C | I |
|------|-------------|---|---|---|---|
| Plant manager | Operations lead | | A | | |
| OR engineer | Project lead | R | | | |
| Robotics integrator | External vendor | | | C | |
| Shop-floor operators | Production team | | | C | I |
| Health & safety | Ergonomics SME | | | C | |

## Milestones

| Week | Milestone | Deliverable |
|------|-----------|-------------|
| 1 | Discovery & data audit | Process map, task-time distributions |
| 2 | Twin scaffold | SimPy model with MES I/O hooks |
| 3 | MILP v1 | Single-tick model validated |
| 4 | Rolling-horizon + warm start | Solve < 5 s confirmed |
| 5 | Multi-agent layer | Q-agents live, reward shaping validated |
| 6 | Monte Carlo runs | Results table with CIs |
| 7 | Executive readout | Charter close-out, go/no-go recommendation |

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Twin drift from reality | High | High | Re-sync every 5 ticks; alert at 8% drift |
| MILP infeasible under tight fatigue caps | Medium | High | Soft constraints; fallback heuristic |
| MARL agents oscillate | Medium | Medium | ε-decay; MILP always arbitrates |
| Operator buy-in resistance | Medium | Medium | 4-week advisory-only pilot |
